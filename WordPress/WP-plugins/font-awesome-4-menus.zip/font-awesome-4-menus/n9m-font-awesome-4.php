<?php
/*
Plugin Name: Font Awesome 4 Menus
Plugin URI: https://www.newnine.com/plugins/font-awesome-4-menus
Description: Join the retina/responsive revolution by easily adding Font Awesome 4.7.0 icons to your WordPress menus and anywhere else on your site! No programming necessary.
Version: 4.7.0
Author: New Nine Media
Author URI: https://www.newnine.com
License: GPLv2 or later
*/

/*
    Copyright 2013-2016  NEW NINE MEDIA  (tel : +1-800-288-9699)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

class FontAwesomeFour {

    public static $defaults = array(
        'maxcdn_location' => 'https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.min.css',
        'spacing' => 1,
        'stylesheet' => 'local',
        'version' => '4.7.0'
    );

    function __construct(){
        global $wp_version;

        add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_action( 'admin_notices', array( $this, 'admin_notices' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'wp_enqueue_scripts' ) );

        add_filter( 'nav_menu_css_class', array( $this, 'nav_menu_css_class' ) );
        add_filter( 'walker_nav_menu_start_el', array( $this, 'walker_nav_menu_start_el' ), 10, 4 );

        add_shortcode( 'fa', array( $this, 'shortcode_icon' ) );
        add_shortcode( 'fa-stack', array( $this, 'shortcode_stack' ) );
    }

    function admin_enqueue_scripts( $hook ){
        if( 'settings_page_n9m-font-awesome-4-menus' == $hook ){
            wp_enqueue_style( 'n9m-admin-font-awesome-4', plugins_url( 'css/font-awesome.min.css', __FILE__ ), false, self::$defaults[ 'version' ] );
        }
    }

    function admin_menu(){
        add_submenu_page( 'options-general.php', 'Font Awesome 4 Menus', 'Font Awesome', 'edit_theme_options', 'n9m-font-awesome-4-menus', array( $this, 'admin_menu_cb' ) );
    }

    function admin_menu_cb(){
        if( $_POST && check_admin_referer( 'n9m-fa' ) ){
            $settings = array();
            switch( $_POST[ 'n9m_location' ] ){
                case 'local':
                case 'maxcdn':
                case 'none':
                    $settings[ 'stylesheet' ] = $_POST[ 'n9m_location' ];
                    break;
                case 'other':
                    $settings[ 'stylesheet' ] = 'other';
                    $settings[ 'stylesheet_location' ] = sanitize_text_field( $_POST[ 'n9m_location-other-location' ] );
                    break;
            }
            if( isset( $_POST[ 'n9m_text_spacing' ] ) ){
                $settings[ 'spacing' ] = 1;
            } else {
                $settings[ 'spacing' ] = 0;
            }
            update_option( 'n9m-font-awesome-4-menus', $settings );
            print '<div class="updated"><p>您的设置已保存！</p></div>';
        }
        $settings = get_option( 'n9m-font-awesome-4-menus', self::$defaults );
        print ' <div class="wrap">
                    <h2><i class="fa fa-thumbs-o-up"></i> ' . get_admin_page_title() . '</h2>
                    <p>感谢您使用<a href="https://www.newnine.com" target="_blank">New Nine</a>的Font Awesome 4 Menus！要查看可用的图标，<a href="http://www.fontawesome.com.cn/faicons/" target="_blank">请单击此处访问Font Awesome网站</a>。</p>
                    <form action="' . admin_url( 'options-general.php?page=n9m-font-awesome-4-menus' ) . '" method="post">
                        <h3>Font Awesome 样式表</h3>
                        <p>选择要如何在网站上加载Font Awesome 4的CSS（如果有的话）：</p>
                        <table class="form-table">
                            <tbody>
                                <tr>
                                    <th scope="row">从以下位置加载CSS：</th>
                                    <td>
                                        <fieldset>
                                            <legend class="screen-reader-text"><span>Load Font Awesome 4 From</span></legend>
											<label for="n9m_location-local"><input type="radio" name="n9m_location" id="n9m_location-local" value="local"' . ( 'local' == $settings[ 'stylesheet' ] ? ' checked' : false ) . '> 本地插件文件夹（默认）</label>
                                            <br />
											<label for="n9m_location-maxcdn"><input type="radio" name="n9m_location" id="n9m_location-maxcdn" value="maxcdn"' . ( 'maxcdn' == $settings[ 'stylesheet' ] ? ' checked' : false ) . '> 官方Font Awesome CDN <span class="description">（<a href="https://www.staticfile.org/" target="_blank">由Staticfile CDN支持的Font Awesome CDN</a>）</span></label>
                                            <br />
											<label for="n9m_location-other"><input type="radio" name="n9m_location" id="n9m_location-other" value="other"' . ( 'other' == $settings[ 'stylesheet' ] ? ' checked' : false ) . '> 选择你的自定义位置：</label> <input type="text" name="n9m_location-other-location" id="n9m_location-other-location" placeholder="在此处输入完整的url" class="regular-text" value="' . ( isset( $settings[ 'stylesheet_location' ] ) ? $settings[ 'stylesheet_location' ] : '' ) . '">
                                            <br />
											<label for="n9m_location-none"><input type="radio" name="n9m_location" id="n9m_location-none" value="none"' . ( 'none' == $settings[ 'stylesheet' ] ? ' checked' : false ) . '> 不要加载Font Awesome 4的CSS <span class="description">（如果你在网站的其他地方加载了Font Awesome 4，请使用这个）</span></label>
                                        </fieldset>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <h3>图标间距</h3>
                        <p>默认情况下，Font Awesome 4菜单在菜单中的图标之前或之后添加一个空格。取消选中下面的框以删除此空间，并更好地控制自定义样式。</p>
                        <p><label for="n9m_text_spacing"><input type="checkbox" name="n9m_text_spacing" id="n9m_text_spacing" value="1"' . ( 1 == $settings[ 'spacing' ] ? ' checked' : false ) . '> 在我的文字和图标之间保持空格 <span class="description">(勾选开启)</span></label>
                        <p>' . wp_nonce_field( 'n9m-fa' ) . '<button type="submit" class="button button-primary">保存设置</button></p>
                    </form>
                </div>';
    }

    function admin_notices(){
        global $current_user, $pagenow;
        if( isset( $_REQUEST[ 'action' ] ) && 'kill-n9m-font-awesome-4-notice' == $_REQUEST[ 'action' ] ){
            update_user_meta( $current_user->data->ID, 'n9m-font-awesome-4-notice-hide', 1 );
        }
        $shownotice = get_user_meta( $current_user->data->ID, 'n9m-font-awesome-4-notice-hide', true );
        if( 'plugins.php' == $pagenow && !$shownotice ){
            print ' <div class="updated is-dismissible">
                        <div style="float: right;"><a href="?action=kill-n9m-font-awesome-4-notice" style="color: #7ad03a; display: block; padding: 8px;">&#10008;</a></div>
                        <p>感谢您安装了<a href="https://www.newnine.com">New Nine</a>的Font Awesome Menus 4！想看看我们还能做些什么吗？在下面订阅我们不常更新的内容，您可以随时取消订阅。</p>
                        <form action="http://newnine.us2.list-manage.com/subscribe/post?u=067bab5a6984981f003cf003d&amp;id=1b25a2aee6" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" target="_blank">
						<p><input type="text" name="FNAME" placeholder="名" value="' . ( !empty( $current_user->first_name ) ? $current_user->first_name : '' ) . '"> <input type="text" name="LNAME" placeholder="姓" value="' . ( !empty( $current_user->last_name ) ? $current_user->last_name : '' ) . '"> <input type="text" name="EMAIL" placeholder="邮箱地址" required value="' . $current_user->user_email . '"> <input type="hidden" id="group_1" name="group[14489][1]" value="1"> <input type="submit" name="subscribe" value="订阅" class="button action"></p>
                        </form>
                    </div>';
        }
    }

    function nav_menu_css_class( $classes ){
        if( is_array( $classes ) ){
            $tmp_classes = preg_grep( '/^(fa)(-\S+)?$/i', $classes );
            if( !empty( $tmp_classes ) ){
                $classes = array_values( array_diff( $classes, $tmp_classes ) );
            }
        }
        return $classes;
    }

    public static function register_uninstall_hook(){
        if( current_user_can( 'delete_plugins' ) ){
            delete_option( 'n9m-font-awesome-4-menus' );
            $users_with_meta = get_users( array(
                'meta_key' => 'n9m-font-awesome-4-notice-hide',
                'meta_value' => 1
            ) );
            foreach( $users_with_meta as $user_with_meta ){
                delete_user_meta( $user_with_meta->ID, 'n9m-font-awesome-4-notice-hide' );
            }
        }
    }

    protected function replace_item( $item_output, $classes ){
        $settings = get_option( 'n9m-font-awesome-4-menus', FontAwesomeFour::$defaults );
        $spacer = 1 == $settings[ 'spacing' ] ? ' ' : '';

        if( !in_array( 'fa', $classes ) ){
            array_unshift( $classes, 'fa' );
        }

        $before = true;
        if( in_array( 'fa-after', $classes ) ){
            $classes = array_values( array_diff( $classes, array( 'fa-after' ) ) );
            $before = false;
        }

        $icon = '<i class="' . implode( ' ', $classes ) . '"></i>';

        preg_match( '/(<a.+>)(.+)(<\/a>)/i', $item_output, $matches );
        if( 4 === count( $matches ) ){
            $item_output = $matches[1];
            if( $before ){
                $item_output .= $icon . '<span class="fontawesome-text">' . $spacer . $matches[2] . '</span>';
            } else {
                $item_output .= '<span class="fontawesome-text">' . $matches[2] . $spacer . '</span>' . $icon;
            }
            $item_output .= $matches[3];
        }
        return $item_output;
    }
    
    function shortcode_icon( $atts ){
        $a = shortcode_atts( array(
            'class' => ''
        ), $atts );
        if( !empty( $a[ 'class' ] ) ){
            $class_array = explode( ' ', $a[ 'class' ] );
            if( !in_array( 'fa', $class_array ) ){
                $class_array[] = 'fa';
            }
            return '<i class="' . implode( ' ', $class_array ) . '"></i>';
        }
    }
    
    function shortcode_stack( $atts, $content = null ){
        $a = shortcode_atts( array(
            'class' => ''
        ), $atts );
        $class_array = array();
        if( empty( $a[ 'class' ] ) ){
            $class_array = array( 'fa-stack' );
        } else {
            $class_array = explode( ' ', $a[ 'class' ] );
            if( !in_array( 'fa-stack', $class_array ) ){
                $class_array[] = 'fa-stack';
            }
        }
        return '<span class="' . implode( ' ', $class_array ) . '">' . do_shortcode( $content ) . '</span>';
    }

    function walker_nav_menu_start_el( $item_output, $item, $depth, $args ){
        if( is_array( $item->classes ) ){
            $classes = preg_grep( '/^(fa)(-\S+)?$/i', $item->classes );
            if( !empty( $classes ) ){
                $item_output = $this->replace_item( $item_output, $classes );
            }
        }
        return $item_output;
    }

    function wp_enqueue_scripts(){
        $settings = get_option( 'n9m-font-awesome-4-menus', self::$defaults );
        switch( $settings[ 'stylesheet' ] ){
            case 'local':
                wp_register_style( 'font-awesome-four', plugins_url( 'css/font-awesome.min.css', __FILE__ ), array(), self::$defaults[ 'version' ], 'all' );
                wp_enqueue_style( 'font-awesome-four' );
                break;
            case 'maxcdn':
                wp_register_style( 'font-awesome-four', self::$defaults[ 'maxcdn_location' ], array(), self::$defaults[ 'version' ], 'all' );
                wp_enqueue_style( 'font-awesome-four' );
                break;
            case 'none':
                break;
            case 'other':
                wp_register_style( 'font-awesome-four', $settings[ 'stylesheet_location' ], array(), self::$defaults[ 'version' ], 'all' );
                wp_enqueue_style( 'font-awesome-four' );
                break;
        }
    }

    public static function write_log( $log ){
        if( is_array( $log ) || is_object( $log ) ){
            error_log( print_r( $log, true ) );
        } else {
            error_log( $log );
        }
    }
    
}
$n9m_font_awesome_four = new FontAwesomeFour();

register_uninstall_hook( __FILE__, array( 'FontAwesomeFour', 'register_uninstall_hook' ) );